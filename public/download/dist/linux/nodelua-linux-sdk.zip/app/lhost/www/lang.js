var VisionLangZh =
{

	LnodeHost 			: "应用管理",
	Restart 			: "启用",
	Stop    			: "禁用",
	Title    			: "标题",
	Action    			: "操作",

	EndItem 			: ""
}

$.lang.update('zh-cn', VisionLangZh)

