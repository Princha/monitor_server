local utils     = require('utils')
local path 	    = require('path')
local conf      = require('ext/conf')
local json      = require('json')
local fs        = require('fs')
local thread    = require('thread')
local querystring = require('querystring')
local rpc       = require('vision/express/rpc')

local function on_status(request, response)
    local method    = 'status'
    local params    = {}

    local IPC_PORT = 39901
    rpc.call(IPC_PORT, method, params, function(err, result)
        if (result) then
            result.now = process.now()
        end
        response:json(result)
    end)
end

local function do_api(request, response, onEnd)
    local api = request.api

    if (api == '/status') then
        on_status(request, response)

    else
        response:sendStatus(400, "No `api` parameters specified!")
    end
end

request.params  = querystring.parse(request.uri.query) or {}
request.api     = request.params['api']
do_api(request, response)

return true
