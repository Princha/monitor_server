local app       = require('app')
local utils     = require('utils')
local request   = require('http/request')
local fs        = require('fs')
local URL       = 'http://192.168.31.149:3000/hosts'
-------------------------------------------------------------------------------
-- exports

function getInfo()
    -- body
    --memony
    local data = fs.readFileSync('/proc/meminfo')
    local list = string.split(data, 'kB\n')
    local MemTotal ,MemFree
    for w in string.gmatch(list[1],"%d+") do
        MemTotal = w
    end
    for w in string.gmatch(list[2],"%d+") do
        MemFree = w
    end

    --cpu
    data = fs.readFileSync('/proc/stat')
    list = string.split(data, '\n')
    local d = string.gmatch(list[1],"%d+")
    local TotalCPUtime = 0;
    local x = {}
    local i = 1
    for w in d do
        TotalCPUtime = TotalCPUtime + w
        x[i] = w
        i = i +1
    end
    local TotalCPUusagetime = 0;
    TotalCPUusagetime = x[1]+x[2]+x[3]+x[6]+x[7]+x[8]+x[9]+x[10]
    local cpuUserPercent = TotalCPUusagetime/TotalCPUtime

    local MemUsed = (MemTotal-MemFree)/MemTotal
    return MemTotal,MemFree,MemUsed,cpuUserPercent,TotalCPUtime,TotalCPUusagetime
end

function monitor()
    -- body
    local mt,mf,mu,cu,tc,tcu = getInfo()
    local options = { form = { MemTotal = mt,MemFree = mf,MemUsed = m,CpuUserPercent = c ,TotalCPUtime = tc,TotalCPUusagetime= tcu}}
    request.post(URL, options, function(err, response, body)
        -- print(response.statusCode, body)
    end)
end

local exports = {}

function exports.conf()

end

function exports.daemon()
    app.daemon()
end

function exports.help()
    app.usage(utils.dirname())
end



function exports.start()
    print('start')
    local options = { form = { status = 'on' }}
    print('post')
    request.post(URL, options, function(err, response, body)
        print(response.statusCode, body)
    end)
    setInterval(5000,monitor)
end

function exports.stop()
    os.execute('lpm kill mqtt')
end




app(exports)
