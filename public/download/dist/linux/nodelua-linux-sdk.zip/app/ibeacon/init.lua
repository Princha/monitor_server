local app       = require('app')
local utils     = require('utils')
local fs        = require('fs')
local path      = require('path')
local json      = require('json')

local bluetooth = require('device/bluetooth')
local rpc       = require('ext/rpc')

local ibeacon   = require('ibeacon')

local SCAN_RESPONSE = 0x04
local RPC_PORT      = 8888

local function onData(err, data)
    if (not data) then
        return

    elseif data:byte(6) == SCAN_RESPONSE then
        return
    end
 
    local message = ibeacon.parseBeaconMessage(data)
    if (message == nil) then
        return
    end

    ibeacon.handleMessage(message)
end

-------------------------------------------------------------------------------
-- 

local rpcMethods = {}
local rpcServer  = nil

function rpcMethods:delete( )
    
end

function rpcMethods:getBeacons()
    return ibeacon.getList()
end

function rpcMethods:getDeviceInfo()
    return ibeacon.deviceInfo
end

-------------------------------------------------------------------------------
-- 

local exports = {}

function onPost()
    ibeacon.postData()
end


function exports.updateSettings()
    local settings = {}
    settings.server         = app.get('beacon.server')
    settings.device_id      = app.get('beacon.device_id')
    settings.device_key     = app.get('beacon.device_key')
    settings.stat_timeout   = app.get('beacon.stat_timeout')
    settings.max_stat_count = app.get('beacon.max_stat_count')
    settings.max_stat_time  = app.get('beacon.max_stat_time')
    settings.env_factor     = app.get('beacon.env_factor')

    --console.log(settings)

    ibeacon.settings = settings
end

function exports.start(mac, timeout)
    ibeacon.loadDeviceInfo(utils.dirname())
    exports.updateSettings()

    local updated = os.uptime()

    local callback = function(err, data)
        if (err) then
            console.log(err)
            return
        end

        updated = os.uptime()
        onData(err, data)

        --console.printBuffer(data)
        --xpcall(onData, utils.traceHandler, err, data)
        --setTimeout(0, function()
        --    onData(err, data)
    end


    local ret = bluetooth.scan(callback)  

    local REPORT_INTERVAL = 1000
    local CHECK_INTERVAL  = 2000 -- in 1/1000 second
    local CHECK_TIMEOUT   = 5    -- in second

    timeout = timeout or REPORT_INTERVAL
    setInterval(timeout, onPost)
    setInterval(CHECK_INTERVAL, function() 
        ibeacon.clearInvalidBeacons()

        local now = os.uptime()
        local span = now - updated

        --console.log(bluetooth.lbluetooth, span)
        if (span > CHECK_TIMEOUT) then
            bluetooth.stop()
        end

        if (not bluetooth.ibluetooth) then
            bluetooth.scan(callback)
        end
    end)
    rpcServer = rpc.server(RPC_PORT, rpcMethods)
end

function exports.status(name)
    local method    = name or 'getBeacons'
    local params    = {}

    rpc.call(RPC_PORT, method, params, function(err, result)
        if (result) then
            console.log(result)
        end
    end)
end

app(exports)
