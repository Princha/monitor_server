local app       = require('app')
local fs        = require('fs')
local express   = require('express')
local request   = require('http/request')
local server    = require('ssdp/server')
local utils     = require('utils')
local path      = require('path')
local json      = require('json')
local conf      = require('ext/conf')
local device    = require('device')

local describe  = require('./describe')

local WEB_PORT  = 9100

local ssdpServer = nil

local exports = {}

local function getRootPath()
    return conf.rootPath
end

-------------------------------------------------------------------------------
-- exports

local function getDeviceServiceList()
    local serviceList = {}

    --local service = {}
    --serviceList[1] = service

    --service.type = 'Hygrothermograph:1'
    --service.url  = 'hygrothermograph.json'

    return serviceList
end

local function getDeviceDescribe()
    local deviceInfo = device.getDeviceInfo()

    local host = "0.0.0.0"
    if (exports.ssdpServer) then
        host = exports.ssdpServer:getLocalAddress() or "0.0.0.0"
    end

    local describe = {}
    describe.version    = 1

    local info = {}
    describe.device   = info
    info.manufacturer = deviceInfo.manufacturer
    info.model        = deviceInfo.model
    info.name         = deviceInfo.model
    info.serialNumber = deviceInfo.serialNumber
    info.type         = deviceInfo.type
    info.udn          = deviceInfo.udn
    info.target       = deviceInfo.target
    info.version      = deviceInfo.version
    info.url          = 'http://' .. host .. ':80'

    info.serviceList = getDeviceServiceList()
    return describe
end

local function onInstall(request, response)
    print('Upload complete.')

    local data = request.body
    local filename = '/tmp/install.zip'
    if (not data) then
        response:json({ ret = -1, error = 'Bad request' })
        return
    end

    local rootPath = nil
    print('file', filename, #data)

    local query = request.query or {}
    local dest = query.dest
    if (dest ~= 'global') then
        rootPath = path.dirname(os.tmpname())
    end

    os.remove(filename)
    fs.writeFileSync(filename, data)

    local upgrade = require('ext/upgrade')
    upgrade.installFile(filename, rootPath, function(err, checkInfo)
        local result = { ret = 0 }

        if (checkInfo.faileds and checkInfo.faileds > 0) then
            result.ret = -1
            result.error = string.format('(%d) error has occurred in the upgrade!', checkInfo.faileds)
        end

        local data = {}
        data.total      = checkInfo.total
        data.totalBytes = checkInfo.totalBytes
        data.updated    = checkInfo.updated
        data.faileds    = checkInfo.faileds
        data.rootPath   = checkInfo.rootPath
        data.name       = checkInfo.name
        result.data = data

        response:json(result)
    end)
end

local function onRemove(request, response)
    local result = { ret = 0 }
    -- TODO: disconnect
    response:json(result)
end

local function onUpgrade(request, response)
    print('Upload complete.')

    local data = request.body
    local filename = '/tmp/update.zip'
    if (not data) then
        response:json({ ret = -1, error = 'Bad request' })
        return
    end

    local query = request.query or {}
    local rootPath = query.rootPath
    print('file', filename, #data)

    os.remove(filename)
    fs.writeFileSync(filename, data)

    local upgrade = require('ext/upgrade')
    upgrade.upgradeFile(filename, rootPath, function(err, checkInfo)
        local result = { ret = 0 }

        if (checkInfo.faileds and checkInfo.faileds > 0) then
            result.ret = -1
            result.error = string.format('(%d) error has occurred in the upgrade!', checkInfo.faileds)
        end

        response:json(result)
    end)
end

local function onRegister(request, response)

    --console.log(request)
    --console.log('body', request.body)
    local body  = json.parse(request.body)
    local result = describe.put(body.uid,body.id,body.key)
    if (result == 0) then
        response:send('{"code":200,"api":"register","result":"success"}')

    else
        response:send('{"code":400,"api":"register","result":"fault"}')
    end
end

local function onDisconnect(request, response)
    local result = { ret = 0 }
    -- TODO: disconnect
    response:json(result)
end

local function onConnect(request, response)
    local result = { ret = 0 }
    -- TODO: connect
    response:json(result)
end

local function onGetDevice(request, response)
    response:json(getDeviceDescribe())
end

local function onGetDeviceJson(request, response)
    local result = {}

    result.code = 200
    result.result = 'success'
    result.api = '/devices.json'

    if (describe and describe.get) then
        result.data = describe.get()
    end

    response:json(result) 
end

local function onGetRoot(request, response)
    response:send("Node.lua SSDP Server " .. process.version)
end

local function startWebServer()
    local app = express({ })

    app:on('error', function(err) 
        print('SSDP WEB Server', err)
        process:exit()
    end)

    app:get("/",            onGetRoot)
    app:get("/connect",     onConnect)
    app:get("/device",      onGetDevice)
    app:get("/device.json", onGetDeviceJson)
    app:get("/disconnect",  onDisconnect)

    app:post("/install",    onInstall)
    app:post("/register",   onRegister)
    app:post("/remove",     onRemove)   
    app:post("/upgrade",    onUpgrade)

    app:listen(WEB_PORT)
end

-------------------------------------------------------------------------------
-- exports

function exports.help()
    app.usage(utils.dirname())

    print([[
Available command:

- scan          Scan all SSDP device or services
- start         Start SSDP server
- view [ip]     View SSDP device information
]])

end

function exports.scan(serviceType, timeout)
    local client = require('ssdp/client')
    local list = {}

    local grid = app.table({20, 24, 24})

    print("Start scaning...")

    grid.line()
    grid.cell("IP", "UID", "Model")
    grid.line('=')


    local ssdpClient = client({}, function(response, rinfo)
        if (list[rinfo.ip]) then
            return
        end

        local headers   = response.headers
        local item      = {}
        item.remote     = rinfo
        item.usn        = headers["usn"] or ''

        list[rinfo.ip] = item

        --console.log(headers)

        local model = headers['X-DeviceModel']
        local name = rinfo.ip .. ' ' .. item.usn
        if (model) then
            name = name .. ' ' .. model
        end

        grid.cell(rinfo.ip, item.usn, model)
    end)

    -- search for a service type 
    serviceType = serviceType or 'urn:schemas-upnp-org:service:cmpp-iot'
    ssdpClient:search(serviceType)

    local scanCount = 0
    local scanTimer = nil
    local scanMaxCount = timeout or 3

    scanTimer = setInterval(1000, function()
        ssdpClient:search(serviceType)
        print(" .\r")

        scanCount = scanCount + 1
        if (scanCount >= scanMaxCount) then
            clearInterval(scanTimer)
            scanTimer = nil
            
            ssdpClient:stop()

            grid.line()
            print("End scaning...")
        end
    end)
end

function exports.start()
    local deviceInfo = device.getDeviceInfo()
    
    local server = require('ssdp/server')

    local ssdpSig = "Node.lua/" .. process.version .. ", UPnP/1.0, ssdp/" .. server.version
    local model = deviceInfo.model .. '/' .. process.version
    local options = { udn = deviceInfo.udn, ssdpSig = ssdpSig, deviceModel = model }
    exports.ssdpServer = server(options)

    local localAddress = exports.ssdpServer:getLocalAddress() or '0.0.0.0'
    local localtion = "http://" .. localAddress .. ':' .. WEB_PORT .. '/device'
    exports.ssdpServer.location = localtion

    startWebServer()
    print('SSDP server started.')
end

function exports.view(host)
    if (not host) then
        print('ssdp: Not enough arguments provided!')
        print('ssdp: Try `lpm ssdp help` for more information!')
        return
    end

    local url = "http://" .. host .. ":" .. WEB_PORT .. "/device"
    request(url, function(err, response, data)
        --console.log(err, data)

        if (err) then
            print(err)
            return
        end

        data = json.parse(data) or {}
        console.log(data)
    end)
end

function exports.test()
    --local server = require('ssdp/server')
    --exports.ssdpServer = server({})

    console.log('device info: ', device.getDeviceInfo())

    --console.log('device describe: ', getDeviceDescribe())


    local list = {}
    local faces = os.networkInterfaces()
    for k, v in pairs(faces) do
        if (k == 'lo') then
            goto continue
        end

        for _, item in ipairs(v) do
            if (item.family == 'inet') then
                --console.log(item)
                list[#list + 1] = item
            end
        end

        ::continue::
    end

    local item = list[1] or {}
    local mac = utils.bin2hex(item.mac)
    console.log(mac)
   
end

app(exports)
