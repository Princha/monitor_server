#!/bin/sh

# 安装 Node.lua
# ======

# 这个脚本用于将 Node.lua 安装到开发板上
# 打包时将复制此文件到升级包根目录

export NODE_ROOT=/usr/local/lnode
export USR_SBIN=/usr/sbin

mkdir -p ${NODE_ROOT}/app/
mkdir -p ${NODE_ROOT}/bin/
mkdir -p ${NODE_ROOT}/conf/
mkdir -p ${NODE_ROOT}/lua/

cp -rf app/* ${NODE_ROOT}/app/
cp -rf bin/* ${NODE_ROOT}/bin/
cp -rf conf/* ${NODE_ROOT}/conf/
cp -rf lua/* ${NODE_ROOT}/lua/
cp -rf package.json ${NODE_ROOT}/

# add execute permissions
chmod -R 777 ${NODE_ROOT}/bin/*

rm -rf ${USR_SBIN}/lnode
rm -rf ${USR_SBIN}/lpm

ln -s ${NODE_ROOT}/bin/lnode ${USR_SBIN}/lnode
ln -s ${NODE_ROOT}/bin/lpm ${USR_SBIN}/lpm

echo 'Finish!'
